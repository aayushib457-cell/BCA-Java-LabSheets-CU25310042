public class Q1 {
    public static void main(String[] args) {
        String name = "Aayushi";
        int age = 20;
        String college = "ABC College";

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("College: " + college);
    }
}