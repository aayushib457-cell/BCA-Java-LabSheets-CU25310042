public class Q11 {
    
}
